# NO EXTERNAL NETWORK CALLS OR TELEMETRY

import re
import pandas as pd
import pdfplumber
from docx import Document
import io

QUESTIONS = [
    {
        "id": 1,
        "question": "Does the Detainee have a history of violence?",
        "keywords": ["violence", "assault", "battery", "attacked", "stabbed", "aggravated assault", "violent behaviour", "convicted of assault"],
    },
    {
        "id": 2,
        "question": "Does the Detainee have a history of sexual assault?",
        "keywords": ["sexual assault", "rape", "sexual abuse", "molestation", "sexual offence"],
    },
    {
        "id": 3,
        "question": "Does the Detainee have a history of escaping custody?",
        "keywords": ["escaped", "absconded", "absconding", "escaped custody", "absconder", "walked away"],
    },
    {
        "id": 4,
        "question": "Does the Detainee have a history of involvement in Organised Crime or Outlaw Motorcycle Gangs?",
        "keywords": ["organised crime", "organized crime", "outlaw motorcycle", "bikie", "gang member", "gang affiliation"],
    },
    {
        "id": 5,
        "question": "Does the Detainee have a history of or conviction for drug use?",
        "keywords": ["drug", "drugs", "possession", "trafficking", "methamphetamine", "heroin", "cocaine", "drug conviction"],
    },
    {
        "id": 6,
        "question": "Is the Detainee from a correctional facility or was transferred from another detention centre?",
        "keywords": ["transferred from", "transferred", "from", "released from prison", "received from correctional facility"],
    },
    {
        "id": 7,
        "question": "Does the Detainee have a history of self-harm or made threats of self-harm?",
        "keywords": ["self-harm", "suicide attempt", "suicidal ideation", "threatened self-harm", "attempted suicide"],
    },
]

NEGATION_TOKENS = ["no", "none", "denies", "not", "without", "no history"]

def extract_text_from_pdf(file):
    with pdfplumber.open(file) as pdf:
        return "".join(page.extract_text() for page in pdf.pages if page.extract_text())

def extract_text_from_docx(file):
    doc = Document(file)
    return "\n".join(para.text for para in doc.paragraphs)

def extract_text_from_excel(file):
    try:
        return pd.read_excel(file, engine='openpyxl').to_string()
    except Exception:
        return pd.read_excel(file, engine='xlrd').to_string()

def extract_text_from_csv(file):
    return pd.read_csv(file).to_string()

def extract_text_from_txt(file):
    return file.read().decode("utf-8")

def extract_text(file):
    try:
        if file.name.endswith(".pdf"):
            return extract_text_from_pdf(io.BytesIO(file.read()))
        elif file.name.endswith(".docx"):
            return extract_text_from_docx(io.BytesIO(file.read()))
        elif file.name.endswith((".xlsx", ".xls")):
            return extract_text_from_excel(io.BytesIO(file.read()))
        elif file.name.endswith(".csv"):
            return extract_text_from_csv(io.BytesIO(file.read()))
        elif file.name.endswith(".txt"):
            return extract_text_from_txt(file)
    except Exception:
        return ""
    return ""

def find_answers(text):
    results = {}
    sentences = re.split(r'(?<=[.!?])\s+', text.lower())

    for q in QUESTIONS:
        results[q["id"]] = "Nil information was provided"
        # evidence hierarchy: 1=explicit_pos, 2=explicit_neg, 3=implied, 4=none
        best_finding = {"text": "", "type": 4, "year": 0}

        for sent in sentences:
            for keyword in q["keywords"]:
                match = re.search(r'\b' + re.escape(keyword) + r'\b', sent)
                if match:
                    # Check for form-like answers like [x] yes
                    checkbox_match = re.search(r'\[\s*x\s*\]\s*(yes|no)', sent)
                    if checkbox_match:
                        is_negated = (checkbox_match.group(1) == 'no')
                    else:
                        # Check for negation tokens in the 5 words preceding the keyword
                        text_before = sent[:match.start()]
                        words_before = text_before.split()
                        is_negated = any(neg_token in words_before[-5:] for neg_token in NEGATION_TOKENS)

                    year_match = re.search(r'\b(20\d{2})\b', sent)
                    year = int(year_match.group(1)) if year_match else 0
                    
                    current_type = 0
                    if "implied" in sent or "imply" in sent:
                        current_type = 3  # Implied
                    elif is_negated:
                        current_type = 2  # Explicit Negative
                    else:
                        current_type = 1  # Explicit Positive

                    if current_type < best_finding["type"] or \
                       (current_type == best_finding["type"] and year > best_finding["year"]):
                        
                        finding_text = " ".join(sent.strip().split()[:10])
                        if current_type == 3:
                            finding_text = f"Implied: {finding_text}"

                        best_finding = {"text": finding_text, "type": current_type, "year": year}
        
        if best_finding["text"]:
            results[q["id"]] = best_finding["text"].capitalize()

    return [results[i+1] for i in range(len(QUESTIONS))]
